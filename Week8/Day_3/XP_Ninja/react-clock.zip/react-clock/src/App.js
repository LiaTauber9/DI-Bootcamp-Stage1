// import './App.css';
import { Time } from './components/Time';

function App() {
  return (
    <div className="App">
      <Time />
    </div>
  );
}

export default App;
